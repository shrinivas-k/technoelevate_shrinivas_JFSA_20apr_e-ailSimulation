package com.te.emailSimulation.controller;

import java.util.List;

import com.te.emailSimulation.Userbean.user.User;

public class service {

	public static boolean deletemessages(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	public static List<User> getAllMessages() {
		// TODO Auto-generated method stub
		return null;
	}

}
