package com.te.emailSimulation.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.te.emailSimulation.Userbean.user.User;

public class controller {
	
	@GetMapping("/userlogin")
	public String getUserForm() {
		return "userlogin";
	}// getEmpForm
	@PostMapping("/login")
	public String authenticate(String name, String password, HttpServletRequest request, ModelMap map) {
		User user=new User(name,password);
		System.out.println(user);
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("loggedIn",user);
//			session.setMaxInactiveInterval(3600);
			map.addAttribute("name",user.getName());
			return "Home";
		} else {
			map.addAttribute("errMsg", "Invalid Credentials");
			return "userlogin+";
		}
	}// authenticate
	


	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap map) {
		session.invalidate();
		map.addAttribute("msg", "logout successfull");
		return "Login";
	}// logout

	@GetMapping("/getDeleteForm")
	public String getDelete(@SessionAttribute(name = "loggedIn", required = false) User user,
			ModelMap map) {
		if (user != null) {
			return "delete";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "Login";
		}
	}//

	@GetMapping("/delete")
	public String deletemsg(int id, @SessionAttribute(name = "loggedIn", required = false)User user,
			ModelMap map) {
		if (user!= null) {
			if (service.deletemessages(id)) {
				map.addAttribute("msg", "Data Deleted successfully for id : " + id);
			} else {
				map.addAttribute("msg", "Could not find Record for id : " + id);
			}
			return "delete";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "Login";
		}

	}//
	@GetMapping("/inbox")
	public String getAllRecords(@SessionAttribute(name = "loggedIn", required = false)User user,
			ModelMap map) {
		if (user != null) {
			List<User> User = service.getAllMessages();
			if (user!= null) {
				
				map.addAttribute("infos", user);
			}else {
				map.addAttribute("errMsg", "No Records Found");
			}
			map.addAttribute("name", user.getName());	
			return "Home";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}
	}
}
