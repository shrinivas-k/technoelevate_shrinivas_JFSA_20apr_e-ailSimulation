package com.te.emailSimulation.controller;

public class JavaMailSender {

	public void send(MimeMessagePreparator mimeMessagePreparator) {
		// TODO Auto-generated method stub
		
	}

}
