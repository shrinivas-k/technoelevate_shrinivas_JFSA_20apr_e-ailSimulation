package com.te.emailSimulation.controller;

public class MimeMessagePreparator {

}
